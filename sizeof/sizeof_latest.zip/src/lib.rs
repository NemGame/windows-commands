use std::fs;
use std::path::Path;
use std::ffi::CStr;
use std::os::raw::c_char;

#[unsafe(no_mangle)]
pub extern "C" fn get_folder_size(path: *const c_char) -> u64 {
    if path.is_null() {
        return 0;
    }
    // Safety: caller must provide a valid null-terminated C string.
    let cstr = unsafe { CStr::from_ptr(path) };
    let path_str = cstr.to_string_lossy();
    folder_size(Path::new(&*path_str))
}

fn folder_size(path: &Path) -> u64 {
    let mut size = 0;
    if path.is_dir() {
        let entries = match fs::read_dir(path) {
            Ok(e) => e,
            Err(_) => return 0,
        };
        for entry in entries {
            let entry = match entry {
                Ok(e) => e,
                Err(_) => continue,
            };
            let path = entry.path();
            if path.is_dir() {
                size += folder_size(&path);
            } else {
                size += fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
            }
        }
    }
    size
}