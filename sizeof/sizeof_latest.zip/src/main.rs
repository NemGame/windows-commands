use std::env;
use std::fs;
use std::path::Path;
use std::time::Instant;

pub struct LogData {
    pub size: u64,
    pub log: bool,
    pub start: Instant, 
}

fn get_folder_size(path: &Path, log: &mut LogData, recursion_limit: i64) -> u64 {
    let mut size = 0;
    if path.is_dir() {
        let entries = match fs::read_dir(path) {
            Ok(e) => e,
            Err(_) => return 0,
        };
        for entry in entries {
            let entry = match entry {
                Ok(e) => e,
                Err(_) => continue,
            };
            let path = entry.path();
            if path.is_dir() && (recursion_limit > 0 || recursion_limit == -2) {
                size += get_folder_size(&path, log, if recursion_limit == -2 { -2 } else { recursion_limit - 1 });
            } else {
                size += fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
                if log.log {
                    log.size += 1;
                    if log.start.elapsed().as_millis() >= 1 {
                        print!("\r{} files found", log.size);
                        log.start = Instant::now();
                    }
                }
            }
        }
    }
    size
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        println!("sizeof <fájlnév>");
        return;
    }
    let mut do_log:bool = false;
    let mut do_time:bool = false;
    let mut found_path:usize = 0;
    let mut recursion_limit: i64 = -2;
    let mut index: usize = 1;
    loop {
        if index >= args.len() {
            break;
        }
        let arg = &args[index];
        if arg.trim().to_lowercase() == "-l" {
            do_log = true;
        } else if arg.trim().to_lowercase() == "-t" {
            do_time = true;
        } else if arg.trim().to_lowercase() == "-s" {
            if index + 1 < args.len() {
                recursion_limit = args[index + 1].parse::<i64>().unwrap_or(0);
                if args[index + 1] != format!("{}", recursion_limit) {
                    recursion_limit = 0;
                } else {
                    index += 1;
                }
            } else {
                recursion_limit = 0;
            };
            index += 1;
        } else if found_path == 0 {
            found_path = index;
        }
        index += 1;
    }
    let mut log = LogData {
        size: 0,
        log: do_log,
        start: Instant::now(),
    };
    let default_path = ".".to_string();
    let path = Path::new(if found_path > 0 { &args[found_path] } else { &default_path }.as_str());
    let time = Instant::now();
    let size: f64 = if path.is_file() {
        fs::metadata(path).expect("Hiba a fájl lekérésekor").len() as f64
    } else if path.is_dir() {
        get_folder_size(path, &mut log, recursion_limit) as f64  
    } else {
        eprintln!("A megadott path nem létezik");
        return;
    };
    
    if log.log {
        print!("\r{} files found", log.size);
    }

    let units = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    let mut fsize = size;
    let mut unit_index = 0;

    while fsize >= 1024.0 && unit_index < units.len() - 1 {
        fsize /= 1024.0;
        unit_index += 1;
    };
    
    let formatted = if (fsize * 100.0).fract() == 0.0 {
        format!("{:.0}", fsize) // nincs tizedes
    } else if (fsize * 10.0).fract() == 0.0 {
        format!("{:.1}", fsize) // 1 tizedes
    } else {
        format!("{:.2}", fsize) // 2 tizedes
    };

    println!("{}{} {}", if log.log { "\n" } else { "" }, formatted, units[unit_index]);

    if do_time {
        println!("Took {}ms to finish", time.elapsed().as_millis());
    }
}